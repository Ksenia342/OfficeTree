import Employee from '../models/Employee.js';

const deleteEmployee = async (employeeId) => {
  const result = await Employee.findOneAndDelete({ employeeId });

  if (!result) {
    throw Object.assign(new Error('Employee not found'), { status: 404 });
  }

  return result;
};

export default deleteEmployee;




