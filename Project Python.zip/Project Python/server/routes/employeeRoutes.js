import { Router } from 'express';
import addEmployee from '../modules/addEmployee.js';
import deleteEmployee from '../modules/deleteEmployee.js';
import updateEmployee from '../modules/updateEmployee.js';
import getEmployeeById from '../modules/getEmployeeById.js';
import listEmployeesByManager from '../modules/listEmployeesByManager.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const { managerSurname } = req.query;
    const employees = await listEmployeesByManager(managerSurname);
    res.json(employees);
  } catch (error) {
    next(error);
  }
});

router.get('/:employeeId', async (req, res, next) => {
  try {
    const { employeeId } = req.params;
    const employee = await getEmployeeById(employeeId);
    res.json(employee);
  } catch (error) {
    next(error);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const employee = await addEmployee(req.body);
    res.status(201).json(employee);
  } catch (error) {
    next(error);
  }
});

router.put('/:employeeId', async (req, res, next) => {
  try {
    const { employeeId } = req.params;
    const employee = await updateEmployee(employeeId, req.body);
    res.json(employee);
  } catch (error) {
    next(error);
  }
});

router.delete('/:employeeId', async (req, res, next) => {
  try {
    const { employeeId } = req.params;
    await deleteEmployee(employeeId);
    res.status(204).send();
  } catch (error) {
    next(error);
  }
});

export default router;

