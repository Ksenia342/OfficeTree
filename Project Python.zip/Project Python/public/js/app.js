const API_BASE = `${window.location.origin}/api/employees`;

const createForm = document.getElementById('create-form');
const filterForm = document.getElementById('filter-form');
const findForm = document.getElementById('find-form');
const updateForm = document.getElementById('update-form');
const deleteForm = document.getElementById('delete-form');
const tableBody = document.querySelector('#employee-table tbody');

const showToast = (message, type = 'info') => {
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
};

const serializeForm = (form) => Object.fromEntries(new FormData(form).entries());

const renderEmployees = (employees) => {
  tableBody.innerHTML = '';
  employees.forEach((employee) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${employee.employeeId}</td>
      <td>${employee.surname}</td>
      <td>${employee.salary.toLocaleString('ru-RU')} BYN</td>
      <td>${employee.managerSurname}</td>
    `;
    tableBody.appendChild(row);
  });
};

createForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const payload = serializeForm(createForm);
  payload.salary = Number(payload.salary);

  try {
    const res = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) throw new Error('Не удалось создать запись');
    createForm.reset();
    showToast('Сотрудник добавлен', 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

filterForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const { managerSurname } = serializeForm(filterForm);
  const query = managerSurname ? `?managerSurname=${encodeURIComponent(managerSurname)}` : '';
  try {
    const res = await fetch(`${API_BASE}${query}`);
    if (!res.ok) throw new Error('Не удалось получить данные');
    const employees = await res.json();
    console.table(
      employees.map(({ employeeId, surname, managerSurname, salary }) => ({
        employeeId,
        surname,
        salary,
        managerSurname,
      }))
    );
    renderEmployees(employees);
    showToast('Готово! Проверьте консоль и таблицу', 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

findForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const { employeeId } = serializeForm(findForm);
  try {
    const res = await fetch(`${API_BASE}/${employeeId}`);
    if (!res.ok) throw new Error('Сотрудник не найден');
    const employee = await res.json();
    updateForm.classList.remove('hidden');
    updateForm.dataset.employeeId = employee.employeeId;
    updateForm.elements.surname.value = employee.surname;
    updateForm.elements.salary.value = employee.salary;
    updateForm.elements.managerSurname.value = employee.managerSurname;
    showToast('Запись найдена, можно редактировать', 'success');
  } catch (error) {
    updateForm.classList.add('hidden');
    showToast(error.message, 'error');
  }
});

updateForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const employeeId = updateForm.dataset.employeeId;
  const payload = serializeForm(updateForm);
  payload.salary = Number(payload.salary);

  try {
    const res = await fetch(`${API_BASE}/${employeeId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Ошибка при обновлении');
    showToast('Изменения сохранены', 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

deleteForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const { employeeId } = serializeForm(deleteForm);
  try {
    const res = await fetch(`${API_BASE}/${employeeId}`, {
      method: 'DELETE',
    });
    if (res.status === 404) throw new Error('Запись не найдена');
    if (!res.ok) throw new Error('Ошибка при удалении');
    deleteForm.reset();
    showToast('Сотрудник удалён', 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

