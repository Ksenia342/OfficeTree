import Employee from '../models/Employee.js';

const addEmployee = async ({ employeeId, surname, salary, managerSurname }) => {
  const existing = await Employee.findOne({ employeeId });
  if (existing) {
    throw Object.assign(new Error('Employee with this ID already exists'), {
      status: 409,
    });
  }

  const record = await Employee.create({
    employeeId,
    surname,
    salary,
    managerSurname,
  });

  return record;
};

export default addEmployee;




