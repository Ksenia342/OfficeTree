import Employee from '../models/Employee.js';

const getEmployeeById = async (employeeId) => {
  const employee = await Employee.findOne({ employeeId });
  if (!employee) {
    throw Object.assign(new Error('Employee not found'), { status: 404 });
  }
  return employee;
};

export default getEmployeeById;


