import mongoose from 'mongoose';

const connectDb = async () => {
  const { MONGODB_URI } = process.env;

  if (!MONGODB_URI) {
    console.warn('[DB] Missing MONGODB_URI env variable. Set it via .env.');
    return;
  }

  try {
    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log('[DB] MongoDB connected');
  } catch (error) {
    console.error('[DB] Connection error', error.message);
    process.exit(1);
  }
};

export default connectDb;




