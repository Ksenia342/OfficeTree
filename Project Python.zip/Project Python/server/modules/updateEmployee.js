import Employee from '../models/Employee.js';

const updateEmployee = async (employeeId, data) => {
  const allowedFields = ['surname', 'salary', 'managerSurname'];
  const updatePayload = {};

  allowedFields.forEach((field) => {
    if (data[field] !== undefined) {
      updatePayload[field] = data[field];
    }
  });

  const updated = await Employee.findOneAndUpdate(
    { employeeId },
    updatePayload,
    { new: true }
  );

  if (!updated) {
    throw Object.assign(new Error('Employee not found'), { status: 404 });
  }

  return updated;
};

export default updateEmployee;




