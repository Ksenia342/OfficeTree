import Employee from '../models/Employee.js';

const listEmployeesByManager = async (managerSurname) => {
  const criteria = managerSurname ? { managerSurname } : {};
  return Employee.find(criteria).sort({ surname: 1 });
};

export default listEmployeesByManager;




